//
//  PhotoRobotsCell.swift
//  police
//
//  Created by user on 21.09.2022.
//

import UIKit

class PhotoRobotsCell: UICollectionViewCell {
    
    @IBOutlet weak var image: UIImageView!
    
}
