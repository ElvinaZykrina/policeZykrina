//
//  CustomButton.swift
//  police
//
//  Created by user on 27.09.2022.
//

import UIKit

@IBDesignable
class CustomButton: UIButton {

    @IBInspectable var borderWidth: CGFloat = 0.0 {
        didSet { self.layer.borderWidth = borderWidth }
    }
    
    @IBInspectable var borderColor: UIColor = .clear {
        didSet { self.layer.borderColor = borderColor.cgColor }
    }
    
    @IBInspectable var borderRadius: CGFloat = 0.0 {
        didSet { self.layer.cornerRadius = borderRadius }
    }
    
}
